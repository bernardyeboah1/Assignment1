// Immidiate invoked function express

(function(){
    function Start(){
        console.log("Application started....");
    }
    window.addEventListener("load",Start);
})();